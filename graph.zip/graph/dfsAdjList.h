#pragma once
#include "struct.h"
#include <stdio.h>
int dfs(ALGraph *g,int v);
